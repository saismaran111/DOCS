<?php
session_start();
$mysqli=NEW MySQLi('localhost','root','','mydb');
if(isset($_GET['vkey'])){
	$vkey = $_GET['vkey'];
	
	$resultset = $mysqli->query("SELECT verified,vkey FROM users WHERE verified = 0 AND vkey = '$vkey' LIMIT 1");
	if($resultset->num_rows ==1){
		$update = $mysqli->query("UPDATE users SET verified = 1 WHERE vkey = '$vkey' LIMIT 1");
		if($update){
			echo " your account has been verified. you may login here.";
			if(isset($_POST['login'])){
				header('location:http://localhost/googledocs/verify.php');
			}
		}else{
			echo $mysqli->error;
		}
	}
	else{
		echo "already verified";
	}
}else{
	die("went wrong");
}

?>

<html>
<head>
	<title>DOCS</title>
	<link rel="stylesheet" type="text/css" href="style.css"/>
	<style type="text/css">
	button{
		background: black;
		color: white;
		font-weight: bold;
		font-size: 20px;
		cursor: pointer;
	}
	button:hover{
		font-size: 30px;
	}

	</style>
</head>
<body>
	<form name="myform" autocomplete="on" action="" method="post">
			<span><?php echo $error;?></span>
			<table cellpadding="10px" cellspacing="10px">
			<tr><td></td><td><button name="login">LOGIN</button></td></tr>
		</table>				
	</form>

</body>
</html>